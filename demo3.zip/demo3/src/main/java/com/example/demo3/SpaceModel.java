package com.example.demo3;

import java.util.ArrayList;

public class SpaceModel {
    PubSub publisher;
    ArrayList<Star> starsList;
    ArrayList<Asteroid> asteroidsList;
    double windowSize;

    public SpaceModel( double winSize ) {
        asteroidsList = new ArrayList<>();
        starsList = new ArrayList<>();
        windowSize = winSize;
        addStars();
        addAsteroids();
    }

    public void addPublisher( PubSub pubSub ) {
        publisher = pubSub;
    }

    private void addStars() {
        for ( int i = 0; i < 100; i++ ) {
            this.starsList.add( new Star( Math.random() - .5, Math.random() - .5 ) );
        }
    }

    private void addAsteroids() {
        for ( int i = 0; i < 15; i++ ) {
            this.asteroidsList.add( new Asteroid( windowSize ) );
        }
//        this.asteroidsList.add( new Asteroid( windowSize ) );
    }

    public ArrayList<Star> getStarsList() {
        return this.starsList;
    }

    public ArrayList<Asteroid> getAsteroidsList() {
        return this.asteroidsList;
    }

    public void moveAsteroids() {
        for ( Asteroid asteroid : this.asteroidsList ) {
            asteroid.move();
        }
        publisher.notifySubs();
    }

    public void spinAsteroids() {
        for ( Asteroid asteroid : this.asteroidsList ) {
            asteroid.spin();
        }
        publisher.notifySubs();
    }

}
