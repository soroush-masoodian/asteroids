package com.example.demo3;

public class InteractionModel {
    PubSub publisher;
    SpaceModel model;
    double worldRotation;
    double rotationSpeed;
    boolean isMoving, isSpinning;
    double cursorX, cursorY;

    public InteractionModel() {
        worldRotation = 0;
        rotationSpeed = 1;
        isMoving = true;
        isSpinning = true;
        cursorX = 0;
        cursorY = 0;
    }

    public void setModel( SpaceModel spaceModel ) {
        model = spaceModel;
    }

    public void addPublisher( PubSub pubSub ) {
        publisher = pubSub;
    }

    public void incrementWorldRotation() {
        worldRotation += 5e-2;
        publisher.notifySubs();
    }

    public double getWorldRotation() {
        return worldRotation;
    }

    public double getRotationSpeed() {
        return rotationSpeed;
    }

    public void setRotationSpeed( double newSpeed ) {
        rotationSpeed = newSpeed;
        publisher.notifySubs();
    }

    public void setIsMoving( boolean moving ) {
        isMoving = moving;
        publisher.notifySubs();
    }

    public boolean getIsMoving() {
        return isMoving;
    }

    public void setIsSpinning( boolean spinning ) {
        isSpinning = spinning;
        publisher.notifySubs();
    }

    public boolean getIsSpinning() {
        return isSpinning;
    }

    public double getCursorX() {
        return cursorX;
    }

    public void setCursorX( double x ) {
        cursorX = x;
        publisher.notifySubs();
    }

    public double getCursorY() {
        return cursorY;
    }

    public void setCursorY( double y ) {
        cursorY = y;
        publisher.notifySubs();
    }

    public double rotateX( double x, double y, double a ) {
        return x * Math.cos( a ) - y * Math.sin( a );
    }

    public double rotateY( double x, double y, double a ) {
        return x * Math.sin( a ) + y * Math.cos( a );
    }
}
