package com.example.demo3;

import javafx.scene.paint.Paint;

public class CursorView extends SpaceView {

    final double SCALE_FACTOR = 1.75;

    public CursorView( double windowSize ) {
        super( windowSize );
    }

    @Override
    public void draw() {
        gc.clearRect( 0, 0, windowSize, windowSize );
        gc.save();
        gc.translate( (-iModel.getCursorX() + .5) * windowSize, ( -iModel.getCursorY() + .5 ) * windowSize );
        gc.translate( (1 - iModel.getCursorX() ) * windowSize, ( 1 - iModel.getCursorY() ) * windowSize );
        gc.rotate( iModel.getWorldRotation() );
        gc.scale( SCALE_FACTOR,SCALE_FACTOR );
        drawStars();
        gc.restore();

        gc.save();
        gc.translate( (-iModel.getCursorX() + .5) * windowSize, ( -iModel.getCursorY() + .5 ) * windowSize );
        drawAsteroids();
        gc.restore();
    }

    @Override
    public void drawAsteroids() {
        for ( Asteroid asteroid : model.getAsteroidsList() ) {
            gc.save();
            gc.setFill( Paint.valueOf( "GREY" ) );
            gc.scale( windowSize, windowSize );
            gc.translate( .5, .5 );
            gc.translate( asteroid.getTx(), asteroid.getTy() );
            gc.rotate( asteroid.getAngle() * iModel.getRotationSpeed() );
            gc.scale( SCALE_FACTOR, SCALE_FACTOR );
            gc.fillPolygon( asteroid.getXs(), asteroid.getYs(), asteroid.getXs().length );
            gc.restore();
        }
    }
}
