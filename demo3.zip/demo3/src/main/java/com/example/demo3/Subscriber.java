package com.example.demo3;

public interface Subscriber {
    void receiveNotification();
}
