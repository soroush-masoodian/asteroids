package com.example.demo3;

import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

public class Asteroid {
    double[] xs, ys;
    double radius;
    double angle;
    double tx, ty;
    double dx, dy, da;
    WritableImage bitmap;


    public Asteroid( double winSize ) {
        angle = 0;
        tx = Math.random() - 0.5;
        ty = Math.random() - 0.5;
        radius = Math.random() / 10 + 1e-2;
        da = ( 1e-3 + Math.random() - 0.5 ) * 2; // make it between -1 and 1
        dx = ( 1e-3 + Math.random() - 0.5 ) * 2 / 1e3;
        dy = ( 1e-3 + Math.random() - 0.5 ) * 2 / 1e3;

        // create asteroid shape
        xs = new double[8];
        ys = new double[8];
        for ( int i = 0; i < 8; i++ ) {
            double r = Math.random() * radius + 1e-3;
            xs[i] = r * Math.cos( i * Math.PI / 4 );
            ys[i] = r * Math.sin( i * Math.PI / 4 );
        }

        int writableImageSize = (int) ( radius * winSize );
        bitmap = new WritableImage( writableImageSize, writableImageSize );
        for ( int i = 0; i < writableImageSize; i++ ) {
            for ( int j = 0; j < writableImageSize; j++ )
                bitmap.getPixelWriter().setColor( i, j, Color.BLACK );
        }
    }

    public double[] getXs() {
        return xs;
    }

    public double[] getYs() {
        return ys;
    }

    public double getAngle() {
        return angle;
    }

    public double getRadius() {
        return radius;
    }

    public double getTx() {
        return tx;
    }

    public double getTy() {
        return ty;
    }

    public void move() {
        double newx = tx + dx;
        double newy = ty + dy;

        if ( newx > -.6 && newx < .6 )
            tx = newx;
        else if ( newx < -.6 )
            tx = .6;
        else
            tx = -.6;

        if ( newy > -.6 && newy < .6 )
            ty = newy;
        else if ( newy < -.6 )
            ty = .6;
        else
            ty = -.6;
    }

    public void spin() {
        angle += da;
    }

    public boolean contains( double x, double y ) {
        return false;
    }

}
