package com.example.demo3;

import javafx.scene.input.MouseEvent;

public class SpaceController {
    SpaceModel model;
    InteractionModel iModel;
    PubSub publisher;

    public SpaceController() {
    }

    public void setModel( SpaceModel spaceModel ) {
        model = spaceModel;
    }

    public void setIModel( InteractionModel interactionModel ) {
        iModel = interactionModel;
    }

    public void addPublisher( PubSub pubSub ) {
        publisher = pubSub;
    }

    public void handleAnimationTick() {
        iModel.incrementWorldRotation();
        if ( iModel.getIsSpinning() )
            model.spinAsteroids();
        if ( iModel.getIsMoving() ) {
            model.moveAsteroids();
        }

        publisher.notifySubs();
    }

    public void handleMouseMoved( double x, double y, double windowSize ) {
//        x = iModel.rotateX( x, y, iModel.getWorldRotation() ) / windowSize;
//        y = iModel.rotateY( x, y, iModel.getWorldRotation() ) / windowSize;
        x = x / windowSize;
        y = y / windowSize;

        iModel.setCursorX( x );
        iModel.setCursorY( y );
    }

    public void handleRotationSpeedChange( double newRotationSpeed ) {
        iModel.setRotationSpeed( newRotationSpeed );
    }

    public void handleMovementCheckBoxChanged( boolean isMoving ) {
        iModel.setIsMoving( isMoving );
    }

    public void handleSpinningCheckBoxChanged( boolean isSpinning ) {
        iModel.setIsSpinning( isSpinning );
    }

    public void handleMousePressed( MouseEvent event ) {
    }

    public void handleMouseDragged( MouseEvent event ) {

    }

    public void handleMouseReleased( MouseEvent event ) {

    }

}
