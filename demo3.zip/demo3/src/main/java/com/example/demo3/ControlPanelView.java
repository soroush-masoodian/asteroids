package com.example.demo3;

import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.VBox;

public class ControlPanelView extends VBox {
    Slider slider;
    CheckBox movementCheckBox, spinCheckBox;

    public ControlPanelView() {
        this.setStyle( "-fx-base: #191919; -fx-background-color: #191919; -fx-spacing: 10;" );

        Label label = new Label( "Rotation Speed" );

        slider = new Slider();
        slider.setMin( 1 );
        slider.setMax( 2 );

        movementCheckBox = new CheckBox();
        movementCheckBox.setSelected( true );
        movementCheckBox.setText( "Asteroid Movement" );

        spinCheckBox = new CheckBox();
        spinCheckBox.setSelected( true );
        spinCheckBox.setText( "Asteroid Spin" );

        this.getChildren().addAll( label, slider, movementCheckBox, spinCheckBox );
    }

    public void setupEvents( SpaceController controller ) {
        slider.setOnMouseReleased( event -> controller.handleRotationSpeedChange( slider.getValue() ) );
        movementCheckBox.setOnAction( event -> controller.handleMovementCheckBoxChanged( movementCheckBox.isSelected() ) );
        spinCheckBox.setOnAction( event -> controller.handleSpinningCheckBoxChanged( spinCheckBox.isSelected() ) );
    }

}
