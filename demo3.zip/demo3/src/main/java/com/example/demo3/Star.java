package com.example.demo3;

public class Star {
    final int radius = 1;
    final double C = 1.25; // using this so that when the sky rotates there are starts in the corner
    double posX, posY;

    public Star(double posX, double posY) {
        this.posX = posX * C;
        this.posY = posY * C;
    }

    public Position getPosition() {
        return new Position(posX, posY);
    }

    public int getRadius() {
        return radius;
    }
}
