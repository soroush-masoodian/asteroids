package com.example.demo3;

public class MiniatureView extends SpaceView {
    public MiniatureView( double windowSize ) {
        super( windowSize );
    }
}
