package com.example.demo3;

import javafx.animation.AnimationTimer;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public class MainUI extends StackPane {

    public MainUI( double windowSize ) {
        BorderPane root = new BorderPane();
        VBox leftRoot = new VBox();

        SpaceModel model = new SpaceModel( windowSize );
        SpaceView view = new SpaceView( windowSize );
        MiniatureView miniatureView = new MiniatureView( windowSize / 5 );
        CursorView cursorView = new CursorView( windowSize / 5 );
        ControlPanelView controlPanelView = new ControlPanelView();
        InteractionModel interactionModel = new InteractionModel();
        PubSub notifier = new PubSub();
        SpaceController controller = new SpaceController();

        view.setModel( model );
        view.setIModel( interactionModel );
        view.setupEvents( controller );

        miniatureView.setModel( model );
        miniatureView.setIModel( interactionModel );

        cursorView.setModel( model );
        cursorView.setIModel( interactionModel );
        controlPanelView.setupEvents( controller );

        notifier.addSubscriber( view );
        notifier.addSubscriber( miniatureView );
        notifier.addSubscriber( cursorView );

        model.addPublisher( notifier );
        interactionModel.setModel( model );
        interactionModel.addPublisher( notifier );

        controller.setModel( model );
        controller.setIModel( interactionModel );
        controller.addPublisher( notifier );

        MyTimer animationTimer = new MyTimer();
        animationTimer.setController( controller );
        animationTimer.start();

        leftRoot.getChildren().addAll( miniatureView, cursorView, controlPanelView );
        VBox.setVgrow( leftRoot.getChildren().get( leftRoot.getChildren().size() - 1 ), Priority.ALWAYS );

        root.setLeft( leftRoot );
        root.setCenter( view );
        this.getChildren().add( root );
    }

    private class MyTimer extends AnimationTimer {
        SpaceController controller;
        long previousTime = 0;

        public void setController( SpaceController con ) {
            controller = con;
        }

        @Override
        public void handle( long now ) {
            long dt = now - previousTime;
            if ( dt > 1 ) {
                controller.handleAnimationTick();
                previousTime = now;
            }
        }
    }
}
