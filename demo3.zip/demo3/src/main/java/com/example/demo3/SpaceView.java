package com.example.demo3;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

public class SpaceView extends StackPane implements Subscriber {
    Canvas canvas, offScreenCanvas;
    GraphicsContext gc, offScreenGc;
    SpaceModel model;
    InteractionModel iModel;
    double windowSize;

    public SpaceView( double windowSize ) {
        this.windowSize = windowSize;
        this.setStyle( "-fx-background-color: #000000" );

        canvas = new Canvas( windowSize, windowSize );
        offScreenCanvas = new Canvas( windowSize, windowSize );
        gc = canvas.getGraphicsContext2D();
        offScreenGc = offScreenCanvas.getGraphicsContext2D();

        this.getChildren().add( canvas );
    }

    public void setModel( SpaceModel spaceModel ) {
        this.model = spaceModel;
    }

    public void setIModel( InteractionModel interactionModel ) {
        this.iModel = interactionModel;
    }

    public void setupEvents( SpaceController controller ) {
        this.setOnMouseMoved( event ->
                controller.handleMouseMoved( event.getX(), event.getY(), windowSize )
        );
        this.setOnMousePressed( controller::handleMousePressed );
        this.setOnMouseDragged( controller::handleMouseDragged );
        this.setOnMouseReleased( controller::handleMouseReleased );
    }

    public void draw() {
        gc.clearRect( 0, 0, windowSize, windowSize );
        gc.save();
        gc.translate( windowSize / 2, windowSize / 2 );
        gc.rotate( iModel.getWorldRotation() );
        drawStars();
        gc.restore();

        drawAsteroids();
    }

    public void receiveNotification() {
        draw();
    }

    public void drawStars() {
        gc.setFill( Color.WHITE );
        for ( Star star : model.getStarsList() ) {
            Position starPos = star.getPosition();
            gc.fillOval(
                    starPos.x * this.windowSize,
                    starPos.y * this.windowSize,
                    star.getRadius(),
                    star.getRadius()
            );
        }
    }

    public void drawAsteroids() {
        for ( Asteroid asteroid : model.getAsteroidsList() ) {
            gc.save();
            gc.setFill( Color.GREY );
            gc.scale( windowSize, windowSize );
            gc.translate( .5, .5 );
            gc.translate( asteroid.getTx(), asteroid.getTy() );
            gc.rotate( asteroid.getAngle() * iModel.getRotationSpeed() );
            gc.fillPolygon( asteroid.getXs(), asteroid.getYs(), asteroid.getXs().length );
            gc.restore();
        }
    }
}
